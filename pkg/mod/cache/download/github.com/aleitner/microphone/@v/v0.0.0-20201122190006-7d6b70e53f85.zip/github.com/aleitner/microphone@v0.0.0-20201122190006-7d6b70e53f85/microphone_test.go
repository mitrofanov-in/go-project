package microphone_test

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestStreamer(t *testing.T) {
	assert.True(t, false)
}
