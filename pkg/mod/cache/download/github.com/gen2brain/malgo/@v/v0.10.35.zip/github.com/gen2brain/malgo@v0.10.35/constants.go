package malgo

const (
	simdAlignment = 64
)
